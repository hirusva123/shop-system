import tkinter as tk
from tkinter import messagebox, simpledialog, ttk
import json
import os
from datetime import datetime

# Data file paths
PRODUCTS_FILE = 'products.json'
SALES_FILE = 'sales.json'

class ShopSystem:
    def __init__(self):
        self.products = []
        self.sales = []
        self._load_data()

    def _load_data(self):
        """
        Loads data from JSON files into products and sales lists.
        """
        if os.path.exists(PRODUCTS_FILE):
            try:
                with open(PRODUCTS_FILE, 'r', encoding='utf-8') as f:
                    self.products = json.load(f)
            except json.JSONDecodeError:
                print(f"Warning: '{PRODUCTS_FILE}' is empty or corrupted. Starting with no products.")
                self.products = []
            except Exception as e:
                print(f"Error loading products from '{PRODUCTS_FILE}': {e}")
                self.products = []

        if os.path.exists(SALES_FILE):
            try:
                with open(SALES_FILE, 'r', encoding='utf-8') as f:
                    self.sales = json.load(f)
            except json.JSONDecodeError:
                print(f"Warning: '{SALES_FILE}' is empty or corrupted. Starting with no sales.")
                self.sales = []
            except Exception as e:
                print(f"Error loading sales from '{SALES_FILE}': {e}")
                self.sales = []

    def _save_data(self):
        """
        Saves products and sales data to JSON files.
        """
        try:
            with open(PRODUCTS_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.products, f, indent=4, ensure_ascii=False)
            # print(f"Products saved successfully to '{PRODUCTS_FILE}'!") # Removed for GUI
        except Exception as e:
            messagebox.showerror("Save Error", f"Error saving products to '{PRODUCTS_FILE}': {e}")

        try:
            with open(SALES_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.sales, f, indent=4, ensure_ascii=False)
            # print(f"Sales saved successfully to '{SALES_FILE}'!") # Removed for GUI
        except Exception as e:
            messagebox.showerror("Save Error", f"Error saving sales to '{SALES_FILE}': {e}")

    def get_product_by_name(self, name):
        """Helper to find a product by name."""
        for p in self.products:
            if p['name'].lower() == name.lower():
                return p
        return None

    # --- Product Management ---

    def add_product(self, name, price, quantity, category):
        """
        Adds a new product to the system.
        Returns True on success, False otherwise.
        """
        if self.get_product_by_name(name):
            messagebox.showerror("Error", "A product with this name already exists. Please choose a different name.")
            return False

        product = {
            'name': name.strip().lower(),
            'price': price,
            'quantity': quantity,
            'category': category.strip()
        }
        self.products.append(product)
        self._save_data()
        messagebox.showinfo("Success", f"Product '{name.title()}' added successfully!")
        return True

    def update_product(self, name_to_update, new_price, new_quantity):
        """
        Updates information for an existing product.
        Returns True on success, False otherwise.
        """
        product = self.get_product_by_name(name_to_update)
        if product:
            product['price'] = new_price
            product['quantity'] = new_quantity
            self._save_data()
            messagebox.showinfo("Success", f"Product '{name_to_update.title()}' updated successfully!")
            return True
        else:
            messagebox.showerror("Error", f"Product '{name_to_update.title()}' not found.")
            return False

    def delete_product(self, name_to_delete):
        """
        Deletes a product from the system.
        Returns True on success, False otherwise.
        """
        original_len = len(self.products)
        self.products = [p for p in self.products if p['name'].lower() != name_to_delete.lower()]

        if len(self.products) < original_len:
            self._save_data()
            messagebox.showinfo("Success", f"Product '{name_to_delete.title()}' deleted successfully!")
            return True
        else:
            messagebox.showerror("Error", f"Product '{name_to_delete.title()}' not found.")
            return False

    # --- Sales Management ---

    def create_new_sale(self, items_to_purchase):
        """
        Creates a new sale record, updates stock.
        items_to_purchase is a list of (product_name, quantity) tuples.
        Returns True on success, False otherwise.
        """
        current_sale_items = []
        total_amount = 0.0
        
        # Validate stock first to prevent partial sales
        # Create a temporary dictionary for stock validation
        temp_products_stock = {p['name'].lower(): p['quantity'] for p in self.products} 
        
        for item_name, quantity_to_purchase in items_to_purchase:
            product = self.get_product_by_name(item_name)
            if not product:
                messagebox.showerror("Sale Error", f"Product '{item_name.title()}' not found.")
                return False
            # Check against the temporary stock
            if temp_products_stock.get(item_name.lower(), 0) < quantity_to_purchase:
                messagebox.showerror("Sale Error", f"Insufficient stock for '{item_name.title()}'. Available: {temp_products_stock.get(item_name.lower(), 0)}")
                return False
            temp_products_stock[item_name.lower()] -= quantity_to_purchase # Simulate stock reduction

        # If all checks pass, proceed with actual sale and update global products list
        for item_name, quantity_to_purchase in items_to_purchase:
            product = self.get_product_by_name(item_name) # Already checked existence
            
            item_total = product['price'] * quantity_to_purchase
            current_sale_items.append({
                'name': product['name'],
                'price': product['price'],
                'quantity': quantity_to_purchase,
                'total': item_total
            })
            total_amount += item_total
            product['quantity'] -= quantity_to_purchase # Reduce actual stock in self.products

        if current_sale_items:
            sale_record = {
                'sale_id': len(self.sales) + 1,
                'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                'items': current_sale_items,
                'total_amount': total_amount
            }
            self.sales.append(sale_record)
            self._save_data()
            messagebox.showinfo("Sale Complete", f"Sale ID: {sale_record['sale_id']}\nTotal Amount: {total_amount:.2f}\nSale recorded successfully!")
            return True
        else:
            messagebox.showinfo("Sale Cancelled", "No items added to the sale.")
            return False


class ShopApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Cosmetic & Fancy Item Shop System")
        self.geometry("800x600")
        self.system = ShopSystem()

        # Main container frame to hold all other frames
        self.container = tk.Frame(self)
        self.container.pack(fill=tk.BOTH, expand=True)
        
        # Configure grid for the container to ensure frames expand
        self.container.grid_rowconfigure(0, weight=1)
        self.container.grid_columnconfigure(0, weight=1)

        # Initialize frames but don't pack them yet
        self.frames = {}
        for F in (MainMenuFrame, ProductMenuFrame, AddProductFrame, ViewProductsFrame, 
                   UpdateProductFrame, DeleteProductFrame, CreateSaleFrame, SalesHistoryFrame):
            page_name = F.__name__
            frame = F(parent=self.container, controller=self)
            self.frames[page_name] = frame
            frame.grid(row=0, column=0, sticky="nsew") # Use grid to layer frames

        self.show_frame("MainMenuFrame")

    def show_frame(self, page_name):
        """Show a frame for the given page name."""
        frame = self.frames[page_name]
        frame.tkraise() # Bring the desired frame to the top
        print(f"DEBUG: Showing frame: {page_name}") # Debug print
        # Call specific refresh methods if needed when showing a frame
        if page_name == "ViewProductsFrame":
            frame.refresh_product_list()
        elif page_name == "CreateSaleFrame":
            frame.refresh_sale_data() # Refresh available products and clear current sale
        elif page_name == "SalesHistoryFrame":
            frame.refresh_sales_history()


# --- Define individual Frame Classes for better organization ---

class MainMenuFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        
        content_frame = tk.Frame(self)
        content_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(content_frame, text="Welcome to the Alpha D lite !", font=("Arial", 18, "bold")).pack(pady=20)

        buttons_frame = tk.Frame(content_frame)
        buttons_frame.pack(pady=10)

        tk.Button(buttons_frame, text="1. Product Management", command=lambda: controller.show_frame("ProductMenuFrame"), width=25, height=2, font=("Arial", 12)).pack(pady=5)
        tk.Button(buttons_frame, text="2. Create New Sale", command=lambda: controller.show_frame("CreateSaleFrame"), width=25, height=2, font=("Arial", 12)).pack(pady=5)
        tk.Button(buttons_frame, text="3. View Sales History", command=lambda: controller.show_frame("SalesHistoryFrame"), width=25, height=2, font=("Arial", 12)).pack(pady=5)
        tk.Button(buttons_frame, text="4. Exit", command=controller.quit, width=25, height=2, font=("Arial", 12)).pack(pady=5)

class ProductMenuFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        content_frame = tk.Frame(self)
        content_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(content_frame, text="Product Management", font=("Arial", 16, "bold")).pack(pady=10)

        buttons_frame = tk.Frame(content_frame)
        buttons_frame.pack(pady=10)

        tk.Button(buttons_frame, text="1. Add Product", command=lambda: controller.show_frame("AddProductFrame"), width=20, font=("Arial", 10)).pack(pady=2)
        tk.Button(buttons_frame, text="2. View All Products", command=lambda: controller.show_frame("ViewProductsFrame"), width=20, font=("Arial", 10)).pack(pady=2)
        tk.Button(buttons_frame, text="3. Update Product", command=lambda: controller.show_frame("UpdateProductFrame"), width=20, font=("Arial", 10)).pack(pady=2)
        tk.Button(buttons_frame, text="4. Delete Product", command=lambda: controller.show_frame("DeleteProductFrame"), width=20, font=("Arial", 10)).pack(pady=2)
        tk.Button(buttons_frame, text="5. Back to Main Menu", command=lambda: controller.show_frame("MainMenuFrame"), width=20, font=("Arial", 10)).pack(pady=2)

class AddProductFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        content_frame = tk.Frame(self)
        content_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(content_frame, text="Add New Product", font=("Arial", 16, "bold")).pack(pady=10)

        tk.Label(content_frame, text="Product Name:").pack(pady=5)
        self.name_entry = tk.Entry(content_frame, width=30)
        self.name_entry.pack(pady=2)

        tk.Label(content_frame, text="Price:").pack(pady=5)
        self.price_entry = tk.Entry(content_frame, width=30)
        self.price_entry.pack(pady=2)

        tk.Label(content_frame, text="Quantity:").pack(pady=5)
        self.quantity_entry = tk.Entry(content_frame, width=30)
        self.quantity_entry.pack(pady=2)

        tk.Label(content_frame, text="Category:").pack(pady=5)
        self.category_entry = tk.Entry(content_frame, width=30)
        self.category_entry.pack(pady=2)

        tk.Button(content_frame, text="Add Product", command=self._submit_add).pack(pady=10)
        tk.Button(content_frame, text="Back to Product Menu", command=lambda: controller.show_frame("ProductMenuFrame")).pack(pady=5)

    def _submit_add(self):
        try:
            name = self.name_entry.get().strip()
            price = float(self.price_entry.get())
            quantity = int(self.quantity_entry.get())
            category = self.category_entry.get().strip()

            if not name or not category:
                messagebox.showerror("Input Error", "Name and Category cannot be empty.")
                return
            if price < 0 or quantity < 0:
                messagebox.showerror("Input Error", "Price and Quantity must be positive numbers.")
                return

            if self.controller.system.add_product(name, price, quantity, category):
                # Clear entries after successful addition
                self.name_entry.delete(0, tk.END)
                self.price_entry.delete(0, tk.END)
                self.quantity_entry.delete(0, tk.END)
                self.category_entry.delete(0, tk.END)
                self.controller.show_frame("ViewProductsFrame") # Go to view products

        except ValueError:
            messagebox.showerror("Input Error", "Please enter valid numbers for Price and Quantity.")

class ViewProductsFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        # Use grid for internal layout
        self.grid_rowconfigure(1, weight=1) # Row for tree_frame
        self.grid_columnconfigure(0, weight=1) # Column for content

        tk.Label(self, text="All Products", font=("Arial", 16, "bold")).grid(row=0, column=0, pady=10, sticky="ew")

        tree_frame = tk.Frame(self)
        tree_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=5) # Fill the allocated grid cell

        tree_scroll_y = tk.Scrollbar(tree_frame, orient="vertical")
        tree_scroll_y.pack(side=tk.RIGHT, fill=tk.Y)
        tree_scroll_x = tk.Scrollbar(tree_frame, orient="horizontal")
        tree_scroll_x.pack(side=tk.BOTTOM, fill=tk.X)

        columns = ("No.", "Name", "Price", "Quantity", "Category")
        self.product_tree = ttk.Treeview(tree_frame, columns=columns, show="headings",
                                         yscrollcommand=tree_scroll_y.set, xscrollcommand=tree_scroll_x.set)
        tree_scroll_y.config(command=self.product_tree.yview)
        tree_scroll_x.config(command=self.product_tree.xview)

        for col in columns:
            self.product_tree.heading(col, text=col, anchor=tk.W)
            self.product_tree.column(col, width=100, anchor=tk.W)
        
        self.product_tree.column("No.", width=50)
        self.product_tree.column("Name", width=150)
        self.product_tree.column("Price", width=80)
        self.product_tree.column("Quantity", width=80)
        self.product_tree.column("Category", width=120)

        self.product_tree.pack(fill=tk.BOTH, expand=True) # Treeview still uses pack within tree_frame
        
        tk.Button(self, text="Back to Product Menu", command=lambda: controller.show_frame("ProductMenuFrame")).grid(row=2, column=0, pady=10)

    def refresh_product_list(self):
        # Clear existing items in the treeview
        for item in self.product_tree.get_children():
            self.product_tree.delete(item)

        if not self.controller.system.products:
            self.product_tree.insert("", tk.END, values=("", "No products added yet.", "", "", ""))
        else:
            for i, product in enumerate(self.controller.system.products):
                self.product_tree.insert("", tk.END, values=(
                    i + 1,
                    product['name'].title(),
                    f"{product['price']:.2f}",
                    product['quantity'],
                    product['category']
                ))

class UpdateProductFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        content_frame = tk.Frame(self)
        content_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(content_frame, text="Update Product", font=("Arial", 16, "bold")).pack(pady=10)

        tk.Label(content_frame, text="Enter Product Name to Update:").pack(pady=5)
        self.name_entry = tk.Entry(content_frame, width=30)
        self.name_entry.pack(pady=2)

        tk.Label(content_frame, text="New Price:").pack(pady=5)
        self.price_entry = tk.Entry(content_frame, width=30)
        self.price_entry.pack(pady=2)

        tk.Label(content_frame, text="New Quantity:").pack(pady=5)
        self.quantity_entry = tk.Entry(content_frame, width=30)
        self.quantity_entry.pack(pady=2)

        tk.Button(content_frame, text="Update Product", command=self._submit_update).pack(pady=10)
        tk.Button(content_frame, text="Back to Product Menu", command=lambda: controller.show_frame("ProductMenuFrame")).pack(pady=5)

    def _submit_update(self):
        try:
            name = self.name_entry.get().strip()
            new_price = float(self.price_entry.get())
            new_quantity = int(self.quantity_entry.get())

            if not name:
                messagebox.showerror("Input Error", "Product name cannot be empty.")
                return
            if new_price < 0 or new_quantity < 0:
                messagebox.showerror("Input Error", "Price and Quantity must be positive numbers.")
                return

            if self.controller.system.update_product(name, new_price, new_quantity):
                self.name_entry.delete(0, tk.END)
                self.price_entry.delete(0, tk.END)
                self.quantity_entry.delete(0, tk.END)
                self.controller.show_frame("ViewProductsFrame") # Go to view products
        except ValueError:
            messagebox.showerror("Input Error", "Please enter valid numbers for Price and Quantity.")

class DeleteProductFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        content_frame = tk.Frame(self)
        content_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        tk.Label(content_frame, text="Delete Product", font=("Arial", 16, "bold")).pack(pady=10)

        tk.Label(content_frame, text="Enter Product Name to Delete:").pack(pady=5)
        self.name_entry = tk.Entry(content_frame, width=30)
        self.name_entry.pack(pady=2)

        tk.Button(content_frame, text="Delete Product", command=self._submit_delete).pack(pady=10)
        tk.Button(content_frame, text="Back to Product Menu", command=lambda: controller.show_frame("ProductMenuFrame")).pack(pady=5)

    def _submit_delete(self):
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showerror("Input Error", "Product name cannot be empty.")
            return

        if messagebox.askyesno("Confirm Deletion", f"Are you sure you want to delete '{name.title()}'?"):
            if self.controller.system.delete_product(name):
                self.name_entry.delete(0, tk.END)
                self.controller.show_frame("ViewProductsFrame") # Go to view products

class CreateSaleFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.current_sale_items_data = [] # To store items added to the current sale before finalization

        # Use grid for internal layout
        self.grid_rowconfigure(2, weight=1) # Row for product_list_frame
        self.grid_rowconfigure(5, weight=1) # Row for current_sale_list_frame
        self.grid_columnconfigure(0, weight=1) # Column for content

        tk.Label(self, text="Create New Sale", font=("Arial", 16, "bold")).grid(row=0, column=0, pady=10, sticky="ew")

        # Display available products for selection
        tk.Label(self, text="Available Products:", font=("Arial", 12, "underline")).grid(row=1, column=0, pady=5, sticky="w")
        
        product_list_frame = tk.Frame(self)
        product_list_frame.grid(row=2, column=0, sticky="nsew", padx=10, pady=5)
        
        self.sale_product_tree = ttk.Treeview(product_list_frame, columns=("Name", "Price", "Quantity"), show="headings")
        self.sale_product_tree.heading("Name", text="Product Name")
        self.sale_product_tree.heading("Price", text="Price")
        self.sale_product_tree.heading("Quantity", text="Available Stock")
        
        self.sale_product_tree.column("Name", width=150, anchor=tk.W)
        self.sale_product_tree.column("Price", width=80, anchor=tk.W)
        self.sale_product_tree.column("Quantity", width=100, anchor=tk.W)
        self.sale_product_tree.pack(fill=tk.BOTH, expand=True)

        # Input fields for adding items to current sale
        input_frame = tk.Frame(self)
        input_frame.grid(row=3, column=0, pady=10)
        input_frame.grid_columnconfigure(1, weight=1) # Allow entry to expand

        tk.Label(input_frame, text="Product Name:").grid(row=0, column=0, padx=5, pady=2, sticky="w")
        self.sale_item_name_entry = tk.Entry(input_frame, width=30)
        self.sale_item_name_entry.grid(row=0, column=1, padx=5, pady=2, sticky="ew")

        tk.Label(input_frame, text="Quantity:").grid(row=1, column=0, padx=5, pady=2, sticky="w")
        self.sale_item_quantity_entry = tk.Entry(input_frame, width=30)
        self.sale_item_quantity_entry.grid(row=1, column=1, padx=5, pady=2, sticky="ew")

        tk.Button(input_frame, text="Add Item to Sale", command=self._add_item_to_current_sale).grid(row=2, column=0, columnspan=2, pady=5)

        # List of items in current sale
        tk.Label(self, text="Items in Current Sale:", font=("Arial", 12, "underline")).grid(row=4, column=0, pady=5, sticky="w")
        
        current_sale_list_frame = tk.Frame(self)
        current_sale_list_frame.grid(row=5, column=0, sticky="nsew", padx=10, pady=5)

        self.current_sale_tree = ttk.Treeview(current_sale_list_frame, columns=("Name", "Quantity", "Price", "Total"), show="headings")
        self.current_sale_tree.heading("Name", text="Product Name")
        self.current_sale_tree.heading("Quantity", text="Quantity")
        self.current_sale_tree.heading("Price", text="Unit Price")
        self.current_sale_tree.heading("Total", text="Item Total")

        self.current_sale_tree.column("Name", width=150, anchor=tk.W)
        self.current_sale_tree.column("Quantity", width=80, anchor=tk.W)
        self.current_sale_tree.column("Price", width=80, anchor=tk.W)
        self.current_sale_tree.column("Total", width=100, anchor=tk.W)
        self.current_sale_tree.pack(fill=tk.BOTH, expand=True)

        self.total_amount_label = tk.Label(self, text="Total: 0.00", font=("Arial", 14, "bold"))
        self.total_amount_label.grid(row=6, column=0, pady=5, sticky="ew")

        bottom_buttons_frame = tk.Frame(self)
        bottom_buttons_frame.grid(row=7, column=0, pady=10)
        tk.Button(bottom_buttons_frame, text="Finalize Sale", command=self._finalize_sale).pack(side=tk.LEFT, padx=5)
        tk.Button(bottom_buttons_frame, text="Clear Sale", command=self._clear_current_sale).pack(side=tk.LEFT, padx=5)
        tk.Button(bottom_buttons_frame, text="Back to Main Menu", command=lambda: controller.show_frame("MainMenuFrame")).pack(side=tk.LEFT, padx=5)

    def _add_item_to_current_sale(self):
        item_name = self.sale_item_name_entry.get().strip().lower()
        quantity_str = self.sale_item_quantity_entry.get().strip()

        if not item_name or not quantity_str:
            messagebox.showerror("Input Error", "Please enter both product name and quantity.")
            return

        try:
            quantity_to_purchase = int(quantity_str)
            if quantity_to_purchase <= 0:
                messagebox.showerror("Input Error", "Quantity must be a positive integer.")
                return
        except ValueError:
            messagebox.showerror("Input Error", "Please enter a valid number for quantity.")
            return

        found_product = self.controller.system.get_product_by_name(item_name)
        if not found_product:
            messagebox.showerror("Error", f"Product '{item_name.title()}' not found.")
            return

        # Check stock for the actual product
        if found_product['quantity'] < quantity_to_purchase:
            messagebox.showerror("Insufficient Stock", f"Insufficient stock for '{found_product['name'].title()}'. Available: {found_product['quantity']}")
            return

        # Add to temporary sale items
        item_total = found_product['price'] * quantity_to_purchase
        self.current_sale_items_data.append({
            'name': found_product['name'],
            'price': found_product['price'],
            'quantity': quantity_to_purchase,
            'total': item_total
        })
        
        # Temporarily reduce stock in the product list for display purposes in the sale menu
        # This is important for subsequent additions within the same sale session
        found_product['quantity'] -= quantity_to_purchase 

        self._update_current_sale_display()
        self._refresh_available_products_for_sale() # Refresh available stock display
        self.sale_item_name_entry.delete(0, tk.END)
        self.sale_item_quantity_entry.delete(0, tk.END)

    def _update_current_sale_display(self):
        # Clear existing items in the treeview
        for item in self.current_sale_tree.get_children():
            self.current_sale_tree.delete(item)

        current_total = 0.0
        if not self.current_sale_items_data:
            self.current_sale_tree.insert("", tk.END, values=("No items added yet.", "", "", ""))
        else:
            for item in self.current_sale_items_data:
                self.current_sale_tree.insert("", tk.END, values=(
                    item['name'].title(),
                    item['quantity'],
                    f"{item['price']:.2f}",
                    f"{item['total']:.2f}"
                ))
                current_total += item['total']
        self.total_amount_label.config(text=f"Total: {current_total:.2f}")

    def _refresh_available_products_for_sale(self):
        # Clear existing items in the available products treeview
        for item in self.sale_product_tree.get_children():
            self.sale_product_tree.delete(item)
        
        if not self.controller.system.products:
            self.sale_product_tree.insert("", tk.END, values=("No products available.", "", ""))
        else:
            for product in self.controller.system.products:
                self.sale_product_tree.insert("", tk.END, values=(
                    product['name'].title(),
                    f"{product['price']:.2f}",
                    product['quantity']
                ))

    def _finalize_sale(self):
        if not self.current_sale_items_data:
            messagebox.showwarning("No Items", "No items have been added to the current sale.")
            return

        if self.controller.system.create_new_sale([(item['name'], item['quantity']) for item in self.current_sale_items_data]):
            self._clear_current_sale() # Clear the display after successful sale
            self.controller.show_frame("SalesHistoryFrame") # Go to sales history after sale
        else:
            messagebox.showerror("Sale Error", "Failed to finalize sale. Please check stock and try again.")

    def _clear_current_sale(self):
        # Revert any temporary stock reductions made for the current sale display
        # This is crucial if the user clears the sale without finalizing
        for item_data in self.current_sale_items_data:
            product = self.controller.system.get_product_by_name(item_data['name'])
            if product:
                product['quantity'] += item_data['quantity']
        
        self.current_sale_items_data = []
        self._update_current_sale_display()
        self._refresh_available_products_for_sale() # Refresh available stock display
        messagebox.showinfo("Sale Cleared", "Current sale items have been cleared.")
        self.controller.system._save_data() # Save the reverted stock

    def refresh_sale_data(self):
        """Called when navigating to the Create Sale frame to reset its state."""
        self._clear_current_sale() # Ensure sale is cleared and stock reverted
        self.sale_item_name_entry.delete(0, tk.END)
        self.sale_item_quantity_entry.delete(0, tk.END)


class SalesHistoryFrame(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller

        # Use grid for internal layout
        self.grid_rowconfigure(1, weight=1) # Row for history_text
        self.grid_columnconfigure(0, weight=1) # Column for content

        tk.Label(self, text="Sales History", font=("Arial", 16, "bold")).grid(row=0, column=0, pady=10, sticky="ew")

        self.history_text = tk.Text(self, wrap="word", height=20, width=80)
        self.history_text.grid(row=1, column=0, sticky="nsew", padx=10, pady=5)
        self.history_text.config(state=tk.DISABLED) # Make it read-only

        tk.Button(self, text="Back to Main Menu", command=lambda: controller.show_frame("MainMenuFrame")).grid(row=2, column=0, pady=10)

    def refresh_sales_history(self):
        self.history_text.config(state=tk.NORMAL)
        self.history_text.delete(1.0, tk.END) # Clear existing content

        if not self.controller.system.sales:
            self.history_text.insert(tk.END, "No sales records available yet.")
        else:
            for sale in self.controller.system.sales:
                self.history_text.insert(tk.END, f"Sale ID: {sale.get('sale_id')}\n")
                self.history_text.insert(tk.END, f"Date: {sale.get('timestamp')}\n")
                self.history_text.insert(tk.END, f"Total Amount: {sale.get('total_amount'):.2f}\n")
                if sale.get('items'):
                    self.history_text.insert(tk.END, "  Items Sold:\n")
                    for item in sale['items']:
                        self.history_text.insert(tk.END, f"    - {item.get('name').title()} x {item.get('quantity')} @ {item.get('price'):.2f}\n")
                self.history_text.insert(tk.END, "-" * 40 + "\n\n")
        self.history_text.config(state=tk.DISABLED)


# Run the application
if __name__ == "__main__":
    app = ShopApp()
    app.mainloop()
